# بناء APK من الهاتف فقط

هذا المشروع مجهز للبناء على GitHub Actions، لذلك لا تحتاج إلى Android Studio أو Android SDK على هاتفك.

## الطريقة

1. أنشئ مستودعًا جديدًا على GitHub باسم `TebyanAI`.
2. ارفع محتويات هذا المشروع إلى المستودع مع الحفاظ على المجلد `.github/workflows/`.
3. ادخل إلى تبويب **Actions**.
4. اختر **Build Tebyan AI APK** ثم **Run workflow**.
5. بعد نجاح البناء افتح نتيجة التشغيل، ومن **Artifacts** نزّل `TebyanAI-debug-apk`.
6. فك الضغط عن الـArtifact على الهاتف وثبّت `app-debug.apk`.

## ملاحظات

- البناء يستخدم JDK 17 وGradle 9.6 وAndroid Gradle Plugin 9.4، وهي توليفة متوافقة حسب توثيق Android الرسمي.
- هذا يولد Debug APK للتجربة. إصدار Release النهائي يحتاج توقيعًا بمفتاح يملكه صاحب التطبيق.
- مفاتيح مزودي الذكاء الاصطناعي لا توضع داخل APK؛ تبقى في الخادم.
