# خارطة التنفيذ

## v0.2 (هذه الحزمة)
- واجهة Android
- بنية Agent
- نماذج Project/Step/Message
- طبقة API configuration
- صلاحية الإنترنت
- مواصفات الخادم

## v0.3
- Backend فعلي
- تسجيل المستخدم
- قاعدة بيانات المشاريع
- Chat API
- بث الردود Streaming

## v0.4
- Agent loop + أدوات البحث والملفات
- مولد الصور
- ذاكرة المشروع

## v0.5
- Website Builder + معاينة
- App Builder
- تصدير المشاريع

## v1.0
- اختبارات وأمان
- تحسين الأداء
- توقيع Release APK/AAB
- نشر المتجر
