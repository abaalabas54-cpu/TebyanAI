package com.tebyan.ai.data

data class Project(
    val id: String,
    val name: String,
    val type: ProjectType,
    val language: String = "ar",
    val updatedAt: Long = System.currentTimeMillis()
)

enum class ProjectType { CHAT, AGENT, IMAGE, WEBSITE, APP }

data class AgentStep(
    val title: String,
    val status: StepStatus = StepStatus.PENDING,
    val detail: String = ""
)

enum class StepStatus { PENDING, RUNNING, DONE, FAILED }

data class ChatMessage(val role: String, val content: String)
