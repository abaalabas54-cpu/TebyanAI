package com.tebyan.ai.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class ProjectStore(context: Context) {
    private val prefs = context.getSharedPreferences("tebyan_projects", Context.MODE_PRIVATE)

    fun list(): List<Project> {
        val raw = prefs.getString("items", "[]") ?: "[]"
        val arr = JSONArray(raw)
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Project(
                o.getString("id"), o.getString("name"),
                ProjectType.valueOf(o.getString("type")),
                o.optString("language", "ar"),
                o.optLong("updatedAt")
            )
        }
    }

    fun create(name: String, type: ProjectType): Project {
        val p = Project(UUID.randomUUID().toString(), name, type)
        val all = list().toMutableList()
        all.add(0, p)
        save(all)
        return p
    }

    private fun save(items: List<Project>) {
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id); put("name", it.name)
                put("type", it.type.name); put("language", it.language)
                put("updatedAt", it.updatedAt)
            })
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }
}
