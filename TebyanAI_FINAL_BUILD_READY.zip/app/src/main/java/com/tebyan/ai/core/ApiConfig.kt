package com.tebyan.ai.core

object ApiConfig {
    // Change this to your deployed backend URL.
    // Example: https://api.your-domain.com/api
    const val DEFAULT_BACKEND = "https://YOUR-TEBYAN-AI-SERVER.example/api"
}
