package com.tebyan.ai

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import com.tebyan.ai.agent.AgentEngine
import com.tebyan.ai.core.BackendClient
import com.tebyan.ai.data.ProjectStore
import com.tebyan.ai.data.ProjectType
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

class MainActivity : Activity() {
    private val scope = MainScope()
    private val backend = BackendClient()
    private lateinit var projectStore: ProjectStore
    private val navy = Color.rgb(13,24,48)
    private val gold = Color.rgb(200,162,74)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectStore = ProjectStore(this)
        showHome()
    }

    private fun base(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 20)
            setBackgroundColor(Color.WHITE)
            layoutDirection = LinearLayout.LAYOUT_DIRECTION_RTL
        }
        root.addView(TextView(this).apply {
            text = "تبيان AI"
            textSize = 30f
            setTextColor(navy)
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        }, LinearLayout.LayoutParams(-1, 70))
        return root
    }

    private fun button(text:String, action:()->Unit) =
        Button(this).apply { this.text=text; textSize=17f; setOnClickListener{action()} }

    private fun showHome() {
        val root=base()
        root.addView(TextView(this).apply {
            text="ذكاء اصطناعي للمحادثة والبحث والتصميم والبرمجة"
            textSize=18f; gravity=Gravity.CENTER; setTextColor(Color.DKGRAY)
        })
        root.addView(button("💬 محادثة ذكية"){showChat()})
        root.addView(button("🤖 Agent — تنفيذ مهمة كاملة"){showAgent()})
        root.addView(button("🎨 مولد الصور"){toast("واجهة المولد جاهزة للربط بالخادم")})
        root.addView(button("🌐 منشئ المواقع"){toast("منشئ المواقع ضمن طبقة الأدوات")})
        root.addView(button("📱 منشئ التطبيقات"){toast("منشئ التطبيقات ضمن طبقة الأدوات")})
        root.addView(button("📁 مشاريعي"){showProjects()})
        root.addView(button("🌍 اللغة: تلقائي"){toast("العربية • English • Deutsch • Français • وغيرها")})
        setContentView(root)
    }

    private fun showChat() {
        val root=base()
        val input=EditText(this).apply { hint="اكتب طلبك…"; minLines=4; gravity=Gravity.TOP or Gravity.RIGHT }
        val out=TextView(this).apply { textSize=16f; setPadding(8,20,8,20) }
        root.addView(input)
        root.addView(button("إرسال"){
            val prompt = input.text.toString().trim()
            if (prompt.isEmpty()) {
                out.text = "اكتب طلبًا أولًا."
            } else {
                out.text = "جارٍ الاتصال بمحرك تبيان AI…"
                scope.launch {
                    backend.chat(prompt).onSuccess { answer ->
                        out.text = answer
                    }.onFailure { err ->
                        out.text = "تعذر الاتصال بالخادم: ${err.message}"
                    }
                }
            }
        })
        root.addView(out); root.addView(button("← الرئيسية"){showHome()})
        setContentView(root)
    }

    private fun showAgent() {
        val root=base()
        val input=EditText(this).apply { hint="مثال: أنشئ موقعًا لمؤسسة تبيان"; minLines=4 }
        val out=TextView(this).apply { textSize=16f; setPadding(8,16,8,16) }
        root.addView(TextView(this).apply {
            text="🤖 الوكيل الذكي\nيخطط للمهمة ثم ينفذها عبر الأدوات."
            textSize=18f
        })
        root.addView(input)
        root.addView(button("تحليل المهمة"){
            val steps=AgentEngine().plan(input.text.toString())
            out.text=steps.mapIndexed{i,s -> "${i+1}. ${s.title} — ${s.status}"}.joinToString("\n")
        })
        root.addView(out); root.addView(button("← الرئيسية"){showHome()})
        setContentView(root)
    }

    private fun showProjects() {
        val root=base()
        val projects = projectStore.list()
        root.addView(TextView(this).apply {
            text = "📁 مشاريعي\n\n" + (if (projects.isEmpty()) "لا توجد مشاريع بعد." else projects.joinToString("\n") { "• ${it.name} — ${it.type}" })
            textSize=18f
        })
        root.addView(button("+ مشروع جديد"){
            projectStore.create("مشروع جديد", ProjectType.AGENT)
            showProjects()
        })
        root.addView(button("← الرئيسية"){showHome()})
        setContentView(root)
    }

    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
