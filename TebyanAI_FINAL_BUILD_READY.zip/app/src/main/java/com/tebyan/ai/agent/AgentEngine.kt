package com.tebyan.ai.agent

import com.tebyan.ai.data.AgentStep
import com.tebyan.ai.data.StepStatus

class AgentEngine {
    fun plan(goal: String): List<AgentStep> = listOf(
        AgentStep("فهم الهدف والمتطلبات", StepStatus.DONE, goal),
        AgentStep("تحديد الأدوات المناسبة", StepStatus.DONE),
        AgentStep("جمع المعلومات والملفات", StepStatus.PENDING),
        AgentStep("تنفيذ المهمة", StepStatus.PENDING),
        AgentStep("مراجعة واختبار", StepStatus.PENDING),
        AgentStep("حفظ وتسليم النتيجة", StepStatus.PENDING)
    )

    fun requiresTool(goal: String): Set<String> {
        val g = goal.lowercase()
        val tools = mutableSetOf<String>()
        if (listOf("ابحث", "بحث", "research", "search").any { g.contains(it) }) tools += "web_search"
        if (listOf("صمم", "صورة", "image", "design").any { g.contains(it) }) tools += "image_generation"
        if (listOf("موقع", "website", "html").any { g.contains(it) }) tools += "website_builder"
        if (listOf("تطبيق", "android", "apk", "app").any { g.contains(it) }) tools += "app_builder"
        return tools
    }
}
