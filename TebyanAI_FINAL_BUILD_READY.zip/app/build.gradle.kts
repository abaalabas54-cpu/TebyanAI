plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
android { namespace = "com.tebyan.ai"; compileSdk = 35
    defaultConfig { applicationId = "com.tebyan.ai"; minSdk = 24; targetSdk = 35; versionCode = 1; versionName = "0.1.0" }
}
