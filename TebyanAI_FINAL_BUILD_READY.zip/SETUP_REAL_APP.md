# تشغيل النسخة الفعلية

## 1) الخادم
داخل مجلد `backend`:
- أنشئ بيئة Python.
- ثبّت `requirements.txt`.
- انسخ `.env.example` إلى `.env`.
- ضع بيانات مزود نموذج الذكاء الاصطناعي.
- شغّل: `uvicorn app.main:app --host 0.0.0.0 --port 8000`

## 2) التطبيق
غيّر `ApiConfig.DEFAULT_BACKEND` إلى عنوان الخادم المنشور مع `/api`.
ثم افتح المشروع في Android Studio وابنِ APK.

## 3) أمان
لا تضع AI_API_KEY داخل التطبيق.
في الإنتاج استخدم HTTPS، مصادقة للمستخدمين، تحديد معدل الطلبات، وتخزينًا آمنًا للمشاريع.

## 4) ما التالي
- قاعدة بيانات ومصادقة.
- Streaming للمحادثة.
- Agent loop حقيقي مع أدوات sandbox.
- توليد الصور.
- Website Builder + معاينة.
- App Builder + build service.
- نظام اشتراكات/حصص إذا لزم.
