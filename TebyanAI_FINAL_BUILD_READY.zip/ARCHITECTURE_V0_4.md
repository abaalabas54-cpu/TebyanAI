# Tebyan AI v0.4 — Architecture

Mobile app:
Android -> HTTPS -> Backend API

Backend modules:
- Auth
- Chat gateway
- Agent orchestrator
- Tool registry
- Project service
- File service
- Image generation adapter
- Website builder
- App builder
- Sandboxed execution service

Provider abstraction:
The backend should expose one internal interface for chat/image models, allowing different providers or self-hosted models without changing the Android app.

Security:
- HTTPS only
- API secrets server-side
- Per-user authorization
- Rate limiting
- Sandbox for generated code
- File size/type limits
- Audit logs
