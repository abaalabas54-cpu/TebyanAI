# تبيان AI — طبقة الخادم المطلوبة

الـAPK لا يحتوي على مفاتيح مزودي الذكاء الاصطناعي. التطبيق يتصل بخادم تبيان AI.

## Endpoints المقترحة
POST /api/chat
POST /api/agent/plan
POST /api/agent/run
POST /api/images/generate
POST /api/projects
GET  /api/projects
POST /api/projects/{id}/files
POST /api/websites/generate
POST /api/apps/generate

## Agent tools
- web_search
- file_reader
- image_generation
- code_runner (معزول sandbox)
- website_preview
- project_storage
- document_export

## قاعدة مهمة
تشغيل كود المستخدم أو المشاريع يجب أن يتم داخل sandbox معزول بصلاحيات محدودة، وليس داخل خادم API الرئيسي.

## اللغات
الواجهة تستخدم مفاتيح ترجمة قابلة للتوسعة، مع RTL للعربية وLTR للغات الأخرى.
