import os
from typing import List, Dict, Any
import httpx

class Provider:
    name = "base"
    async def chat(self, messages: List[Dict[str, str]], model: str) -> str:
        raise NotImplementedError

class OpenAICompatibleProvider(Provider):
    def __init__(self, name: str, base_url: str, api_key: str):
        self.name, self.base_url, self.api_key = name, base_url.rstrip("/"), api_key

    async def chat(self, messages, model):
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        payload = {"model": model, "messages": messages, "temperature": 0.7}
        async with httpx.AsyncClient(timeout=120) as client:
            r = await client.post(f"{self.base_url}/chat/completions", headers=headers, json=payload)
            r.raise_for_status()
            return r.json()["choices"][0]["message"]["content"]

class ModelRouter:
    def __init__(self):
        self.providers = {}
        if os.getenv("OPENAI_API_KEY"):
            self.providers["openai"] = OpenAICompatibleProvider(
                "openai", os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1"),
                os.getenv("OPENAI_API_KEY")
            )
        if os.getenv("GEMINI_API_KEY"):
            self.providers["gemini"] = OpenAICompatibleProvider(
                "gemini", os.getenv("GEMINI_BASE_URL", "https://generativelanguage.googleapis.com/v1beta/openai"),
                os.getenv("GEMINI_API_KEY")
            )
        if os.getenv("ANTHROPIC_COMPAT_API_KEY"):
            self.providers["anthropic"] = OpenAICompatibleProvider(
                "anthropic", os.getenv("ANTHROPIC_COMPAT_BASE_URL", ""),
                os.getenv("ANTHROPIC_COMPAT_API_KEY")
            )

    def available(self):
        return sorted(self.providers.keys())

    async def one(self, provider, model, messages):
        if provider not in self.providers:
            raise RuntimeError(f"Provider not configured: {provider}")
        return await self.providers[provider].chat(messages, model)

    async def best(self, messages):
        # Priority can be changed from environment.
        order = os.getenv("MODEL_PRIORITY", "openai,gemini,anthropic").split(",")
        models = {
            "openai": os.getenv("OPENAI_MODEL", "gpt-5.6-luna"),
            "gemini": os.getenv("GEMINI_MODEL", "gemini-3.8-flash"),
            "anthropic": os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5"),
        }
        errors = []
        for p in order:
            p = p.strip()
            if p in self.providers:
                try:
                    return await self.one(p, models[p], messages), p, models[p]
                except Exception as e:
                    errors.append(f"{p}:{type(e).__name__}")
        raise RuntimeError("No model succeeded: " + ", ".join(errors))

    async def ensemble(self, messages, providers):
        results = []
        for p in providers:
            if p in self.providers:
                model = {
                    "openai": os.getenv("OPENAI_MODEL", "gpt-5.6-luna"),
                    "gemini": os.getenv("GEMINI_MODEL", "gemini-3.8-flash"),
                    "anthropic": os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5"),
                }[p]
                try:
                    results.append({"provider": p, "model": model,
                                    "content": await self.one(p, model, messages)})
                except Exception as e:
                    results.append({"provider": p, "error": type(e).__name__})
        return results
