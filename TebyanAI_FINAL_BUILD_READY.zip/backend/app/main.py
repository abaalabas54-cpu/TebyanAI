import os
from typing import List, Optional
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import httpx
from dotenv import load_dotenv
from .providers import ModelRouter

load_dotenv()

app = FastAPI(title="Tebyan AI API", version="0.3.0")

router = ModelRouter()
AI_BASE_URL = os.getenv("AI_BASE_URL", "").rstrip("/")
AI_API_KEY = os.getenv("AI_API_KEY", "")
AI_MODEL = os.getenv("AI_MODEL", "")

class Message(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    messages: List[Message]
    language: str = "auto"

class ChatResponse(BaseModel):
    content: str
    model: str

class AgentRequest(BaseModel):
    goal: str
    language: str = "auto"

class AgentResponse(BaseModel):
    goal: str
    steps: List[str]

@app.get("/health")
def health():
    return {"ok": True, "service": "tebyan-ai"}

@app.get("/api/models")
def models():
    return {"providers": router.available(), "multi_model": True}

@app.post("/api/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    messages = [m.model_dump() for m in req.messages]
    try:
        content, provider, model = await router.best(messages)
        return ChatResponse(content=content, model=f"{provider}:{model}")
    except Exception:
        return ChatResponse(
            content="تم تشغيل واجهة تعدد النماذج، لكن لم يتم إعداد أي مفاتيح مزود على الخادم بعد.",
            model="not-configured"
        )

@app.post("/api/ensemble")
async def ensemble(req: ChatRequest):
    messages = [m.model_dump() for m in req.messages]
    requested = os.getenv("ENSEMBLE_PROVIDERS", "openai,gemini,anthropic").split(",")
    return {"results": await router.ensemble(messages, [x.strip() for x in requested])}

@app.post("/api/agent/plan", response_model=AgentResponse)
def agent_plan(req: AgentRequest):
    goal = req.goal.strip()
    if not goal:
        raise HTTPException(status_code=400, detail="goal is required")
    return AgentResponse(goal=goal, steps=[
        "فهم الهدف والمتطلبات",
        "تحديد الأدوات والموارد اللازمة",
        "جمع المعلومات أو قراءة الملفات",
        "تنفيذ المهمة على مراحل",
        "مراجعة واختبار النتيجة",
        "حفظ النتيجة داخل المشروع"
    ])
