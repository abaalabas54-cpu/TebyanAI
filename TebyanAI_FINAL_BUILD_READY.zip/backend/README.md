# Tebyan AI Backend v0.3

تشغيل محلي:
1. python -m venv .venv
2. تفعيل البيئة الافتراضية
3. pip install -r requirements.txt
4. نسخ `.env.example` إلى `.env` ووضع بيانات مزود AI.
5. uvicorn app.main:app --host 0.0.0.0 --port 8000

Endpoints:
- GET /health
- POST /api/chat
- POST /api/agent/plan

ملاحظة: هذه طبقة أولى فعلية. يجب وضع API key على الخادم فقط.
